﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace PeliculasWCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IService1" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IService1
    {
        //-----------CRUD PELICULA----------------
        [OperationContract]
        Pelicula createPelicula(Pelicula pelicula);
        [OperationContract]
        Pelicula updatePelicula(Pelicula pelicula);
        [OperationContract]
        void deletePelicula(int ID);
        [OperationContract]
        Pelicula selectPelicula(int ID);
        [OperationContract]
        IEnumerable<Pelicula> obtenerPeliculas();

        //------------CRUD CALIFICACION-----------
        [OperationContract]
        Calificacion createCalificacion(Calificacion calificacion);
        [OperationContract]
        Calificacion updateCalificacion(Calificacion calificacion);
        [OperationContract]
        void deleteCalificacion(int ID);
        [OperationContract]
        Calificacion selectCalificacion(int ID);
        [OperationContract]
        IEnumerable<Calificacion> obtenerCalificaciones();
        // TODO: agregue aquí sus operaciones de servicio
    }


    // Utilice un contrato de datos, como se ilustra en el ejemplo siguiente, para agregar tipos compuestos a las operaciones de servicio.
    [DataContract]
    public class Pelicula
    {
        public int _ID;
        public string _Nombre;
        public string _Genero;
        public string _Director;
        public float _Puntaje;
        public ICollection<Calificacion> Calificacion { get; set; }
        public Pelicula(int _ID, string _Nombre, string _Genero, string _Director,float _Puntaje)
        {
            this.ID = _ID;
            this.Nombre = _Nombre;
            this.Genero = _Genero;
            this.Director = _Director;
            this.Puntaje = _Puntaje;
        }
        [DataMember(Order = 1)]
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        [DataMember(Order = 2)]
        public string Nombre
        {
            get { return _Nombre; }
            set { _Nombre = value; }
        }
        [DataMember(Order = 3)]
        public string Genero
        {
            get { return _Genero; }
            set { _Genero = value; }
        }
        [DataMember(Order = 4)]
        public string Director
        {
            get { return _Director; }
            set { _Director = value; }
        }
        [DataMember(Order = 5)]
        public float Puntaje
        {
            get { return _Puntaje; }
            set { _Puntaje = value; }
        }
    }
    [DataContract]
    public class Calificacion
    {
        public int _ID;
        public float _Puntaje;
        public float _Promedio { get; set; }
        public string _Comentario;
        public int _IDPelicula;
        public virtual Pelicula Pelicula { get; set; }

        public Calificacion(int _ID, float _Puntaje, float _Promedio, string _Comentario, int _IDPelicula)
        {
            this.ID = _ID;
            this.Puntaje = _Puntaje;
            this.Promedio = _Promedio;
            this.Comentario = _Comentario;
            this.IDPelicula = _IDPelicula;
        }
        [DataMember(Order = 1)]
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public float Puntaje
        {
            get { return _Puntaje; }
            set { _Puntaje = value; }
        }
        [DataMember(Order = 3)]
        public float Promedio
        {
            get { return _Promedio; }
            set { _Promedio = value; }
        }
        [DataMember(Order = 4)]
        public string Comentario
        {
            get { return _Comentario; }
            set { _Comentario = value; }
        }
        [DataMember(Order = 5)]
        public int IDPelicula
        {
            get { return _IDPelicula; }
            set { _IDPelicula = value; }
        }
    }
}
