﻿using System;
using System.Collections.Generic;
using System.Configuration;//Agregar libreria
using System.Data.SqlClient;//Agregar libreria
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace PeliculasWCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
    // NOTE: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Service1.svc o Service1.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class Service1 : IService1
    {
        string connection_string = ConfigurationManager.ConnectionStrings["PeliculasDBConnectionString"].ConnectionString.ToString();//connection to database
        //--------------CRUD PELICULA------------------
        public Pelicula createPelicula(Pelicula pelicula)
        {
            SqlConnection con = new SqlConnection(connection_string);
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO T_Pelicula(Nombre,Genero,Director,Puntaje) VALUES(@Nombre,@Genero,@Director,@Puntaje)", con);
            cmd.Parameters.AddWithValue("@Nombre", pelicula.Nombre);
            cmd.Parameters.AddWithValue("@Genero", pelicula.Genero);
            cmd.Parameters.AddWithValue("@Director", pelicula.Director);
            cmd.Parameters.AddWithValue("@Puntaje", pelicula.Puntaje);
            cmd.ExecuteNonQuery();
            con.Close();
            return pelicula;
        }
        public Pelicula updatePelicula(Pelicula pelicula)
        {
            SqlConnection con = new SqlConnection(connection_string);
            SqlCommand cmd = new SqlCommand("UPDATE T_Pelicula SET Nombre = @Nombre, Genero = @Genero,Director = @Director, Puntaje = @Puntaje WHERE ID = @ID");
            cmd.Parameters.AddWithValue("@ID", pelicula.ID);
            cmd.Parameters.AddWithValue("@Nombre", pelicula.Nombre);
            cmd.Parameters.AddWithValue("@Genero", pelicula.Genero);
            cmd.Parameters.AddWithValue("@Director", pelicula.Director);
            cmd.Parameters.AddWithValue("@Puntaje", pelicula.Puntaje);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return pelicula;
        }
        public void deletePelicula(int ID)
        {
            SqlConnection con = new SqlConnection(connection_string);
            SqlCommand cmd = new SqlCommand("DELETE FROM T_Pelicula WHERE ID = @ID");
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public Pelicula selectPelicula(int ID)
        {
            Pelicula pelicula = new Pelicula(0, "","","",0);
            SqlConnection con = new SqlConnection(connection_string);
            SqlCommand cmd = new SqlCommand("Select * FROM T_Pelicula WHERE ID = @ID ");
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = con;
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    pelicula.ID = reader.GetInt32(0);
                    pelicula.Nombre = reader.GetString(1);
                    pelicula.Genero = reader.GetString(2);
                    pelicula.Director = reader.GetString(3);
                    pelicula.Puntaje = (float)reader.GetDouble(4);
                }
            }
            //cmd.ExecuteNonQuery();
            con.Close();
            reader.Close();
            return pelicula;
        }
        public IEnumerable<Pelicula> obtenerPeliculas()
        {
            List<Pelicula> peliculas = new List<Pelicula>();
            SqlConnection con = new SqlConnection(connection_string);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from T_Pelicula", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    peliculas.Add(new Pelicula(Convert.ToInt32(dr[0].ToString()), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), float.Parse(dr[4].ToString())));
                }
            }
            con.Close();
            return peliculas;
        }

        //-----------------Calificacion
        public Calificacion createCalificacion(Calificacion calificacion)
        {
            SqlConnection con = new SqlConnection(connection_string);
            con.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO T_Calificacion(Puntaje,Promedio,Comentario,IDPelicula) VALUES(@Puntaje,@Promedio,@Comentario,@IDPelicula)", con);
            cmd.Parameters.AddWithValue("@Puntaje", calificacion.Puntaje);
            cmd.Parameters.AddWithValue("@Promedio", calificacion.Promedio);
            cmd.Parameters.AddWithValue("@Comentario", calificacion.Comentario);
            cmd.Parameters.AddWithValue("@IDPelicula", calificacion.IDPelicula);
            cmd.ExecuteNonQuery();
            con.Close();
            return calificacion;
        }
        public Calificacion updateCalificacion(Calificacion calificacion)
        {
            SqlConnection con = new SqlConnection(connection_string);
            SqlCommand cmd = new SqlCommand("UPDATE T_Calificacion SET Puntaje = @Puntaje, Promedio = @Promedio,Comentario = @Comentario, IDPelicula = @IDPelicula WHERE ID = @ID");
            cmd.Parameters.AddWithValue("@ID", calificacion.ID);
            cmd.Parameters.AddWithValue("@Puntaje", calificacion.Puntaje);
            cmd.Parameters.AddWithValue("@Promedio", calificacion.Promedio);
            cmd.Parameters.AddWithValue("@Comentario", calificacion.Comentario);
            cmd.Parameters.AddWithValue("@IDPelicula", calificacion.IDPelicula);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return calificacion;
        }
        public void deleteCalificacion(int ID)
        {
            SqlConnection con = new SqlConnection(connection_string);
            SqlCommand cmd = new SqlCommand("DELETE FROM T_Calificacion WHERE ID = @ID");
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = con;
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        public Calificacion selectCalificacion(int ID)
        {
            Calificacion calificacion = new Calificacion(0, 0, 0, "", 0);
            SqlConnection con = new SqlConnection(connection_string);
            SqlCommand cmd = new SqlCommand("Select * FROM T_Calificacion WHERE ID = @ID ");
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Connection = con;
            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    calificacion.ID = reader.GetInt32(0);
                    calificacion.Puntaje = (float)reader.GetDouble(1);
                    calificacion.Promedio = (float)reader.GetDouble(2);
                    calificacion.Comentario = reader.GetString(3);
                    calificacion.IDPelicula = reader.GetInt32(4);
                }
            }
            //cmd.ExecuteNonQuery();
            con.Close();
            reader.Close();
            return calificacion;
        }
        public IEnumerable<Calificacion> obtenerCalificaciones()
        {
            List<Calificacion> calificaciones = new List<Calificacion>();
            SqlConnection con = new SqlConnection(connection_string);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from T_Calificacion", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows == true)
            {
                while (dr.Read())
                {
                    calificaciones.Add(new Calificacion(Convert.ToInt32(dr[0].ToString()), float.Parse(dr[1].ToString()), float.Parse(dr[2].ToString()), dr[3].ToString(), Convert.ToInt32(dr[4].ToString())));
                }
            }
            con.Close();
            return calificaciones;
        }
    }
}

